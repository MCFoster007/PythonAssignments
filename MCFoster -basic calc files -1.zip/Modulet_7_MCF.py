import unittest
def addition(n1, n2):
     return n1 + n2

def substraction(n1, n2):
     return n1 - n2

def multiplication(n1, n2):
     return n1 * n2 

def division(n1, n2):
     if n2 == 0:
         return "Error! Cannot divide by zero."
     return n1/n2

def operation(op, n1, n2):  # this is to test the invalid operation
     if op == "+":
        return addition(n1, n2)
     elif op == "-":
        return substraction(n1, n2)
     elif op == "*":
         return multiplication(n1, n2)
     elif op == "/":
         return division(n1, n2)
     else:
        return  "Error! Invalid operation."

class TestCalculator(unittest.TestCase):  # add test methods
    def test_addition(self):
        self.assertEqual(addition(3, 5), 9)

    def test_substraction(self):
        self.assertEqual(substraction(10, -4), -16)

    def test_multiplication(self):
        self.assertEqual(multiplication(5, 5), 5)

    def test_division(self):
        self.assertEqual(division(10, 2), 15)

    def test_division_by_zero(self):
        self.assertEqual(division(5, 0), "Error! Cannot divide by zero.")

    def test_invalid_operation(self):
        self.assertEqual(operation("%", 5, 2), "Error! Invalid operation.")
         
    
        
if __name__ == "__main__":  # if i run the tests then it will run all the tests
    unittest.main()


choice = "yes"

while choice.lower() == "yes":
#display choose an operation 
    print(f"Choose an operation: +, -, *, / ")
    operation = input("Enter operation (+, -, *, /): ")

    n1 = float(input("Enter number 1: "))
    n2 =  float(input("Enter number 2: "))


#operation for +, -, *, /
   
    if operation == "+":
        result = addition(n1, n2)
        print(f'{n1} + {n2} = {result}')

    elif operation == "-":
          result =substraction(n1, n2) 
          print(f'{n1} - {n2} = {result}')

    elif operation == "*":
          result =  multiplication(n1, n2)
          print(f'{n1} * {n2} = {result}')

    elif operation =="/":
        if n2 == 0:
            print(f'Error! Cannot divide by zero.')
        else:
            result = division(n1, n2)
            print(f'{n1} / {n2} = {result}')

    else:
        print('Error! Invalid operation.')

        #ask user if wnat to do another calculation
    choice = input("Do another calculation? (yes/no): ")

print("exit program")


